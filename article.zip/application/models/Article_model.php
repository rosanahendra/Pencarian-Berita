<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Article_model extends CI_Model
{
	
	public function __construct(){
		parent::__construct();
	}
	
	public function select_article($a)
	{
	    $curl = curl_init();

        curl_setopt_array($curl, array(
          CURLOPT_URL => 'https://newsdata.io/api/1/news?apikey=pub_8436e94b840089a2b7fd6eb0b9759e1af14c&country=id&language=in&category='.$a,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'GET',
        ));
        
        $response = curl_exec($curl);
        
        curl_close($curl);
        
        return $response;
	}
	
		
}

?>
<script>
function confirmation(){
	var txt;
	var r = confirm('Anda yakin akan menghapus data ini ?');	
	if (r == true) {
    	txt = "You pressed OK!";
	return true;
	} else {
    	txt = "You pressed Cancel!";
	return false;
	}
}
</script>