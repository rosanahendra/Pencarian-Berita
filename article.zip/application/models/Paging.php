<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
ob_start();
date_default_timezone_set('Asia/Jakarta');
class Paging extends CI_Model
{    

	public function __construct(){
		parent::__construct();		
	}
    
    public function paging($search, $orderby, $limit, $pages, $halaman, $menu, $show, $lastrow, $num2){
		
		$curl = curl_init();
          curl_setopt_array($curl, array(
              CURLOPT_URL => "https://py.goseler.com/select_article_table_num2?search=".str_replace(' ', '%20', $search)."&orderby=".str_replace(' ', '%20', $orderby),
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => "",
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 100,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => "GET",
          ));
          
          $response = curl_exec($curl);
          $err = curl_error($curl);
          curl_close($curl);
          $query = json_decode($response);
		
		$row = $query->count;
		$start = ($halaman-1)*$limit;
		$lpage = ceil($row/$limit);
		$last = ($lpage-1)*$limit;
		$previous = $halaman-1;
		$next = $halaman+1;
		
		$max = $row-$limit;
		$after = $start;
		$before = $start;
		$j=0;
		$k=2;
		$l=1;
		$m=0;
		$n=1;
		
		$html2 = '<input type="hidden" value='.$menu.' id="menus">
		<div style="float:left;padding-left:20px;color:#fff">Show <font color="#fff">'.$show.'</font> to <font color="#fff">'.$lastrow.'</font> from <font color="#fff">'.$num2.'</font> entries</div>
		<div style="float:right;color:#fff;padding-right:20px">
		<ul class="pagination" style="margin-top:-5px">';
		if($halaman>2){
		$html2 .='
		<li><button id="page_button" class="btn btn-default" value="1" onClick="paging(this.value)">First</button></li>
		';
		}
		
		if($halaman>1){
		$html2 .='
		<li><button id="page_button" class="btn btn-default" value="'.$previous.'" onClick="paging(this.value)">Previous</button></li>
		';
		}
		
		while(($halaman>($j+1)) && $k>0){
		  if($halaman==2){	
		  $page=$halaman-1;
		  }else{
		  $page=$halaman-$k;
		  }
		  $html2 .='
		  <li><button id="page_button" class="btn btn-default" value="'.$page.'" onClick="paging(this.value)">'.$page.'</button></li>
		  ';
		  $j++;
		  $k--;
		}
		
		$html2 .='
		<li><button id="page_current" style="background-color:#A50202;border:1px solid #A50202;color:#fff" class="btn btn-default" value="'.$halaman.'" onClick="paging(this.value)">'.$halaman.'</button></li>
		';
		
		while(($halaman<($lpage-$m)) && $m<2){
		  $page=$halaman+$n;
		  $html2 .='
		  <li><button id="page_button" class="btn btn-default" value="'.$page.'" onClick="paging(this.value)">'.$page.'</button></li>
		  ';
		  $m++;
		  $n++;
		}
		
		if($halaman<($lpage)){
		$html2 .='
		<li><button id="page_button" class="btn btn-default" value="'.$next.'" onClick="paging(this.value)">Next</button></li>
		';
		}
		
		if($halaman<($lpage-1)){
		$html2 .='
		<li><button id="page_button" class="btn btn-default" value="'.$lpage.'" onClick="paging(this.value)">Last</button></li>
		';	
		}
		$html2 .='</ul></div>';
		
		return $html2;
	}
}    