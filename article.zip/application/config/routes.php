<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'Article/index';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['index'] = 'Article/index';

$route['article']	= 'Article/article';
$route['article/create'] = 'Article/article/create';
$route['article/update'] = 'Article/article/update';
$route['article/delete'] = 'Article/article/delete';
$route['article/search'] = 'Article/article/search';
$route['article/print'] = 'Article/article/print';
$route['article/print2'] = 'Article/article/print2';
$route['article/sorting'] = 'Article/article/sorting';
$route['select_article_table']	= 'Article/select_article_table';

$route['all_post']	= 'Article/all_post';