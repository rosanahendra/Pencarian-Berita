<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
ob_start();
class Article extends CI_Controller
{
	public $perpage = 6;
	public $offset = 0;
	public $numlinks = 5;
	
	public function __construct()
    {
        parent:: __construct();
        $this->load->model('article_model');
		$this->load->model('paging');
	}
	
	public function index(){
		redirect('article');
	}
    
	public function article($act = ''){
		$page = 'article';
		$this->data['title'] = 'Data Article';
		if($this->input->get('kategori')){
    		$key = $this->input->get('kategori');
    		$this->data['hasil'] = $this->article_model->select_article($key);
		} else {
		    $this->data['hasil'] = '';
		}
	    $this->data['page'] = 'article';
		$this->load->view('backend/index_view',$this->data);
	}
    
	public function all_post(){
	    $this->data['page'] = 'all_post';
	    $this->data['publish'] = $this->article_model->article_table('Publish');
	    $this->data['draft'] = $this->article_model->article_table('Draft');
	    $this->data['trashed'] = $this->article_model->article_table('Trashed');
	    $this->load->view('backend/index_view',$this->data);
	}
	
	public function crud($page,$act){  
      $this->data['page'] = $page;
      $this->data['action'] = $act;
	  if($act == 'create'){
      	  $pagem = $page.'_model';
          $this->data['ID'] = '';
          if($this->input->post('create')){
              if($this->$pagem->$page('validation')){
				  $this->data['table'] = $this->$pagem->$page('');
				  if($this->$pagem->$page('create')){
					  $this->session->set_flashdata('success','Data berhasil disimpan');
					  if($this->input->get('pages')){
					    redirect('all_post?pages='.$this->input->get('pages'));
					  } else {
					    redirect($page);
					  }
				  } 
              }                   
          }
          $this->load->view('backend/index_view',$this->data);
      } else if($act == 'update'){
          if($this->input->get('ID')){
              $ID = $this->encryption->decrypt(str_replace(' ', '+',$this->input->get('ID')));
          } else {
			  $ID = $this->encryption->decrypt(str_replace(' ', '+',$this->input->post('ID')));
		  }
          $pagem = $page.'_model';
          $this->data['ID'] = $ID;
          if($this->input->post('update')){
              if($this->$pagem->$page('validation')){
				  if($this->$pagem->$page('update')){
					  $this->session->set_flashdata('success','Data berhasil diperbaharui');
					  if($this->input->get('pages')){
					    redirect('all_post?pages='.$this->input->get('pages'));
					  } else {
					    redirect($page);
					  }
				  } else {
					  $this->session->set_flashdata('success','Data berhasil diperbaharui');
					  if($this->input->get('pages')){
					    redirect('all_post?pages='.$this->input->get('pages'));
					  } else {
					    redirect($page);
					  }
				  }   
              } else {
                  $this->data['ID'] = $ID;
              }                    
          }    
          $this->load->view('backend/index_view',$this->data);
      } else if($act == 'print'){
		  $this->users_report();
	  } else if($act == 'print2'){
		  $this->users_currency();
	  } else if($act == 'delete'){
          $pagem = $page.'_model';
		  if($this->input->get('ID') <> ''){
			  if($this->$pagem->$page('delete')){}
			  $this->session->set_flashdata('info','Data berhasil di hapus');
	  	  } else {
			  $this->session->set_flashdata('alert','Maaf Anda harus memilih data yang akan dihapus.');
		  }
		  if($this->input->get('pages')){
		    redirect('all_post?pages='.$this->input->get('pages'));
		  } else {
		    redirect($page);
		  }
      } else if($act == 'search'){
		  
		  if($this->session->userdata($this->input->get('b'))){
		  	  $this->session->unset_userdata($this->input->get('b'));
		  }
		  if($this->input->get('b')){
          $sessionData = array(
              $this->input->get('b') =>  $this->input->get('a'),
              'orderby' => $this->input->get('c'),
			  'menu' => $page
          );
		  }
		  
          $pages=1;
          if($this->input->get('limit')!=$this->session->userdata('limit')){
          $sessionData = array(
              'page' =>  1,
              'menu' => $page
          );
          $this->session->set_userdata($sessionData);	
          $pages = $this->session->userdata('page');
          
          }
          if($this->input->get('page')){
          $sessionData = array(
              'page' => $this->input->get('page'),
              'menu' => $page
          );
          $this->session->set_userdata($sessionData);	
          $pages = $this->session->userdata('page');
          
          }
          $sessionData = array(
              'search'.$page =>  $this->input->get('search'),
			  'search' =>  1,
              'menu' => $page
          );
          $this->session->set_userdata($sessionData);
		  
		  if($this->input->get('limit')){
			 $sessionData = array(
				'limit' =>  $this->input->get('limit')
			 );
			 $this->session->set_userdata($sessionData);
		  }
		  	
          $pagem = $page.'_model';
          echo $this->$pagem->$page('');
      } else if($act == 'sorting'){
          if($this->input->get('a') and $this->input->get('b') and $this->input->get('c')){
			  if($this->session->userdata($this->input->get('b'))){
				  $this->session->unset_userdata($this->input->get('b'));
			  }
			  $sessionData = array(
				  $this->input->get('b') =>  $this->input->get('a'),
				  'orderby' => $this->input->get('c'),
			  );
			  $this->session->set_userdata($sessionData);	
		  }
		  $pagem = $page.'_model';
          $this->data['table'] = $this->$pagem->$page('');
		  $this->load->view('backend/index_view',$this->data);
      } else {
		  
		  if($this->session->userdata($this->input->get('b'))){
		  	  $this->session->unset_userdata($this->input->get('b'));
		  }
		  if($this->input->get('b')){
          $sessionData = array(
              $this->input->get('b') =>  $this->input->get('a'),
              'orderby' => $this->input->get('c'),
			  'menu' => $page
          );
		  }
		  
          $offset = 0;
          $pagem = $page.'_model';
          if($this->input->get('limit')!=$this->session->userdata('limit')){
          $sessionData = array(
              'page' =>  1,
              'menu' => $page
          );
          $this->session->set_userdata($sessionData);	
          $pages = $this->session->userdata('page');
          
          }
		  
           if($this->input->get('limit')){
              $sessionData = array(
                  'limit' =>  $this->input->get('limit'),
                  'menu' => $page
              );
              $this->session->set_userdata($sessionData);	
              $pages = $this->session->userdata('page');
              echo $this->$pagem->$page('');
          } else if($this->input->get('page')){
              $sessionData = array(
                  'page' =>  $this->input->get('page'),
                  'menu' => $page
              );
              $this->session->set_userdata($sessionData);	
	          $pages = $this->session->userdata('page');
    	      echo $this->$pagem->$page('');
          } else {
              $this->data['table'] = $this->$pagem->$page('');
              $pages = $this->session->userdata('page');
              $this->load->view('backend/index_view',$this->data);
          }	
      }
    }
}    
?>    