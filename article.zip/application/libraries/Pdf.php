<?php 
require_once('tcpdf/tcpdf.php');

class Pdf extends Tcpdf
{
    function __construct()
    {
        parent::__construct();
    }
}
?>