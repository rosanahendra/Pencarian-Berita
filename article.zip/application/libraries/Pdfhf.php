<?php
require_once('tcpdf/tcpdf.php');

class Pdfhf extends Tcpdf {
	public function __construct()
    {
        parent:: __construct();
		//$this->load->model('frontend_model');
	}
	
	public function Header() {
		/*$acc = $this->frontend_model->account_app($_SERVER['SERVER_NAME']);
		$query = $this->frontend_model->select_company_profile($acc->acca_code);
		foreach($query->result() as $comp){ 
			$image_file = base_url().$comp->comp_logo;
			if(preg_match('/^.*\.png$/i', $image_file)){
				$this->Image($image_file, 15, 10, 50, '', 'PNG', '', 'T', false, 300, '', false, false, 0, false, false, false);        
			}else if(preg_match('/^.*\.jpg$/i', $image_file)){
				$this->Image($image_file, 15, 10, 50, '', 'JPG', '', 'T', false, 300, '', false, false, 0, false, false, false);    
			}else if(preg_match('/^.*\.gif$/i', $image_file)){
				$this->Image($image_file, 15, 10, 50, '', 'GIF', '', 'T', false, 300, '', false, false, 0, false, false, false);    
			}
		}*/
	}
	public function Footer() {
		$this->SetY(-15);
        $this->SetFont('helvetica', 'T', 8);
		$this->Cell(30, 10, 'Printed : '.date("j F Y, g:i a"), 0, false, 'C', 0, '', 0, false, 'T', 'M');
		$this->Cell(130, 10, 'Page '.$this->getAliasNumPage(), 0, false, 'C', 0, '', 0, false, 'T', 'C');
		//$this->Cell(10, 10, 'Copyright © Rai Fitness '.date("Y"), 0, false, 'C', 0, '', 0, false, 'T', 'M');
	}
}
?>

