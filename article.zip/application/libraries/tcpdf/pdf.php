<?php 
if (!defined('TCPDF_ROOT')) {
    define('TCPDF_ROOT', dirname(__FILE__) . '/');
    require(TCPDF_ROOT . 'tcpdf/tcpdf.php');
}
class Pdf extends TCPDF
{
    function __construct()
    {
        parent::__construct();
    }
}