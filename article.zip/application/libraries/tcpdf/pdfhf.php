<?php
require_once('tcpdf/tcpdf.php');

class pdfhf extends TCPDF {
	public function Header() {
		$image_file = K_PATH_IMAGES.'labanian.jpg';
        $this->Image($image_file, 13, 10, 50, '', 'JPG', '', 'T', false, 300, '', false, false, 0, false, false, false);
	}
	public function Footer() {
		$this->SetY(-15);
        $this->SetFont('helvetica', 'T', 8);
        $this->Cell(0, 10, 'Page '.$this->getAliasNumPage(), 0, false, 'C', 0, '', 0, false, 'T', 'M');
	}
}
?>