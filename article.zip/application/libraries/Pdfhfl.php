<?php
require_once('tcpdf/tcpdf.php');

class Pdfhfl extends Tcpdf {
	public function Header() {
		$image_file = base_url()."public/logo/rf.png";
		if(preg_match('/^.*\.png$/i', $image_file)){
			$this->Image($image_file, 15, 10, 50, '', 'PNG', '', 'T', false, 300, '', false, false, 0, false, false, false);        
		}else if(preg_match('/^.*\.jpg$/i', $image_file)){
			$this->Image($image_file, 15, 10, 50, '', 'JPG', '', 'T', false, 300, '', false, false, 0, false, false, false);    
		}else if(preg_match('/^.*\.gif$/i', $image_file)){
			$this->Image($image_file, 15, 10, 50, '', 'GIF', '', 'T', false, 300, '', false, false, 0, false, false, false);    
		}
	}
	public function Footer() {
		$this->SetY(-15);
        $this->SetFont('helvetica', 'T', 8);
		
		$this->Cell(40, 10, 'Printed : '.date("j F Y, g:i a"), 0, false, 'C', 0, '', 0, false, 'T', 'M');
		$this->Cell(190, 10, 'Page '.$this->getAliasNumPage(), 0, false, 'C', 0, '', 0, false, 'T', 'C');
		$this->Cell(40, 10, 'Copyright © Rai Fitness '.date("Y"), 0, false, 'C', 0, '', 0, false, 'T', 'M');
	}
}
?>