
<!DOCTYPE html>
<html lang="en">

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>
    Article
  </title>
  <!-- Favicon -->
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  <link href="<?php echo base_url(); ?>asset_backend/js/plugins/nucleo/css/nucleo.css" rel="stylesheet" />
  <!--<link href="<?php echo base_url(); ?>asset_backend/js/plugins/@fortawesome/fontawesome-free/css/all.min.css" rel="stylesheet" />-->
  <link rel="stylesheet" href="<?php echo base_url(); ?>asset_backend/font-awesome/css/font-awesome.min.css">
  <!-- CSS Files -->
  <link href="<?php echo base_url(); ?>asset_backend/css/argon-dashboard.css?v=1.1.0" rel="stylesheet" />
  
</head>

<body>
<div id="message">
	<?php if($this->session->flashdata('success')){?>      
	  <div class="col-xs-12">
		  <div class="alert alert-success" id="createAct" style="font-size:13px; color:#333333; width:250px;box-shadow: 4px 4px 4px rgba(0,0,0,0.8);">
			  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			  <?php echo $this->session->flashdata('success');?>
		  </div>
	  </div>
	<?php } ?> 
	<?php if($this->session->flashdata('alert')){?>
	  <div class="col-xs-12">
		  <div class="alert alert-danger" id="deleteAct" style="font-size:13px; width:250px;box-shadow: 4px 4px 4px rgba(0,0,0,0.8);">
			  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			  <?php echo $this->session->flashdata('alert');?>
		  </div>
	  </div>
	<?php } ?> 
	<?php if($this->session->flashdata('info')){?>
	  <div class="col-xs-12">
		  <div class="alert alert-info" id="updateAct" style="font-size:13px; color:#333333; width:250px;box-shadow: 4px 4px 4px rgba(0,0,0,0.8);">
			  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			  <?php echo $this->session->flashdata('info');?>
		  </div>
	  </div>
	<?php } ?>
	<?php if(validation_errors()){ ?>
	  <div class="col-md-12">
		 <div class="alert alert-danger" id="deleteAct" style="font-size:13px; width:250px;box-shadow: 4px 4px 4px rgba(0,0,0,0.8);">
		 	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			<div class="box-body"><?php echo validation_errors(); ?></div>
		 </div>
	 </div>
	 <?php } ?>
</div>	
  <nav class="navbar navbar-vertical fixed-left navbar-expand-md navbar-light bg-white" id="sidenav-main">
    <div class="container-fluid">
      <!-- Toggler -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <!-- Brand -->
      <!-- User -->
      
      <!-- Collapse -->
      <div class="collapse navbar-collapse" id="sidenav-collapse-main">
        <!-- Collapse header -->
        <div class="navbar-collapse-header d-md-none">
          <div class="row">
            <div class="col-6 collapse-brand">
            </div>
            <div class="col-6 collapse-close">
              <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle sidenav">
                <span></span>
                <span></span>
              </button>
            </div>
          </div>
        </div>
        <!-- Form -->
        <!--<form class="mt-4 mb-3 d-md-none">
          <div class="input-group input-group-rounded input-group-merge">
            <input type="search" class="form-control form-control-rounded form-control-prepended" placeholder="Search" aria-label="Search">
            <div class="input-group-prepend">
              <div class="input-group-text">
                <span class="fa fa-search"></span>
              </div>
            </div>
          </div>
        </form>-->
        <!-- Navigation -->
		<div class="wrapper">
			<nav id="sidebar">
				<div class="sidebar-header">
					<h3>Menu</h3>
				</div>
		
				<ul class="list-unstyled components navbar-nav mb-md-3">
		            <li class="menu-list">
						<a href="<?php echo site_url('article'); ?>" onclick="link_urls('article')">
						<i class="fa fa-book"></i> Article</a>
						</a>
					</li>
					<li class=" menu-list">
						<a href="#menu1" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
						<i class="fa fa-users"></i> Posts</a>
						<ul class="collapse	list-unstyled" id="menu1">
						    <li class="li-child nav-item">
								<a href="<?php echo site_url('all_post#Published'); ?>"><i class="fa fa-user-secret"></i><font class="title-menu">All Post</font></a>
							</li>
								
							<li class="li-child nav-item">
								<a href="<?php echo site_url('article/create'); ?>"><i class="fa fa-building"></i><font class="title-menu">Add New</font></a>
							</li>
								
							<li class="li-child nav-item">
								<a href="<?php echo site_url('all_post?status=publish'); ?>"><i class="fa fa-user-secret"></i><font class="title-menu">Preview</font></a>
							</li>
						</ul>
					</li>
				</ul>
			</nav>
		</div>
		<script>
		function link_urls(a){ //alert(a);
			window.location.href = "<?php echo base_url(); ?>/"+a;
		}
		</script>
      </div>
    </div>
  </nav>
  <div class="main-content">
  	<div class="content-body">
		<!-- Navbar -->
    <?php if($page <> 'dashboard' and $page <> 'holiday' and $page <> 'holiday_detail'){ ?>
	<nav class="navbar navbar-top navbar-expand-md navbar-dark" id="navbar-main">
      <div class="container-fluid">
        <!-- Brand -->
        <!-- Form -->
        <!--
        <form class="navbar-search navbar-search-dark form-inline mr-3 d-none d-md-flex ml-lg-auto">
          <div class="form-group mb-0">
            <div class="input-group input-group-alternative">
              <div class="input-group-prepend" style="color:#333333;">
                <span class="input-group-text"><i class="fa fa-search" style="color:#333333;"></i></span>
              </div>
              <input type="text" id="search<?php echo $page; ?>" class="form-control" placeholder='Search' value="<?php if($this->session->userdata('search'.$page)){ echo $this->session->userdata('search'.$page); } ?>" onKeyUp="searching(this.value)" style="text-align:left; float:right; color:#333333;">
            </div>
          </div>
        </form>
        -->
        <!-- User -->
      </div>
    </nav>
    <!-- End Navbar -->
    <!-- Header -->
    <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">
      <div class="container-fluid">
        <div class="header-body">
        </div>
      </div>
    </div>
    <div class="container-fluid mt--7">
      <div class="row">
        <div class="col-xl-12">
	<?php } ?>
		  	<?php 
			include 'page/'.$page."_view.php"; 
		    ?>
		  </div>
      </div>
      <?php if($page <> 'dashboard' and $page <> 'holiday' and $page <> 'holiday_detail'){ ?>
		  <footer class="footer">
			<div class="row align-items-center justify-content-xl-between">
			  <div class="col-xl-6">
				<div class="copyright text-center text-xl-left text-muted">
				  &copy; 2020 <a href="<?php echo site_url('article'); ?>" class="font-weight-bold ml-1" target="_blank">Article</a>
				</div>
			  </div>
			  <div class="col-xl-6">
			  </div>
			</div>
		  </footer>
		</div>
		<?php } ?>
	  </div>
  </div>
  
  <!--   Core   -->
  
  <script src="<?php echo base_url(); ?>asset_backend/js/plugins/jquery/dist/jquery.min.js"></script>
  <script src="<?php echo base_url(); ?>asset_backend/js/plugins/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <!--   Optional JS   -->
  <script src="<?php echo base_url(); ?>asset_backend/js/plugins/chart.js/dist/Chart.min.js"></script>
  <script src="<?php echo base_url(); ?>asset_backend/js/plugins/chart.js/dist/Chart.extension.js"></script>
  <!--   Argon JS   -->
  <script src="<?php echo base_url(); ?>asset_backend/js/datepick.js"></script>
  <script src="<?php echo base_url(); ?>asset_backend/js/argon-dashboard.min.js?v=1.1.0"></script>
  <script src="https://cdn.trackjs.com/agent/v3/latest/t.js"></script>
  <link href="<?php echo base_url(); ?>select/select2.min.css" rel="stylesheet" />
  <script src="<?php echo base_url(); ?>select/select2.min.js"></script>
  <script>
	$(document).ready(function() {
		$('.autocom').select2();
	});
  </script>
  <script>
	$(document).ready(function() {
		$('.datepicker').datepicker({
	
		  format: 'yyyy-mm-dd'
		});
		

		$('.timepicker').timepicker();
	});	
	
    window.TrackJS &&
      TrackJS.install({
        token: "ee6fab19c5a04ac1a32a645abde4613a",
        application: "argon-dashboard-free"
      });
  </script>
  <script>
  
	$(document).ready(function(){
	    $("#createAct").delay(7000).hide(700);
		$("#deleteAct").delay(5000).hide(700);
		$("#updateAct").delay(5000).hide(700);
		$(".alerthide").delay(5000).hide(700);
	    
	});
	
	$(document).ready(function() {
		$('.autocom').select2();
	});
	
	function searching(keyword) {
		var menus = document.getElementById("menus").value;	 
		
		if (window.XMLHttpRequest) {
			xmlhttp = new XMLHttpRequest();
		} else {
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}	
		xmlhttp.onreadystatechange = 
			function(){
			if(xmlhttp.readyState == 4 && xmlhttp.status == 200){
				document.getElementById(menus).innerHTML = xmlhttp.responseText;
			}
			}
		xmlhttp.open("GET", "<?php echo base_url(); ?>"+menus+"/search?search="+keyword+"&ID2=<?php if($this->input->get('ID2')){echo $this->input->get('ID2');} ?>",true);
		xmlhttp.send();
	}

	function paging(page) {
		
	var menus = document.getElementById("menus").value;	 
	//alert(page);
	
	if (window.XMLHttpRequest) {
		xmlhttp = new XMLHttpRequest();
	} else {
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}	
	xmlhttp.onreadystatechange = 
		function(){
		if(xmlhttp.readyState == 4 && xmlhttp.status == 200){
			document.getElementById(menus).innerHTML = xmlhttp.responseText;
		}
		}
	<?php 	
	if($this->session->userdata('search')){
		for($i = 1;$i <= $search_num;$i++){ ?>	
		xmlhttp.open("GET", "<?php echo base_url(); ?>"+menus+"/search?page="+page+"&no=<?php echo $i; ?>&search=<?php echo $this->session->userdata('search'.$page.$i); ?>&ID2=<?php if($this->input->get('ID2')){echo $this->input->get('ID2');} ?>",true);
	<?php } 
	}else{
	?>
		xmlhttp.open("GET", "<?php echo base_url(); ?>"+menus+"?page="+page+"&ID2=<?php if($this->input->get('ID2')){echo $this->input->get('ID2');} ?>",true);
	<?php } ?>
	xmlhttp.send();
	}
	
	function limit(limit) {
		var menus = document.getElementById("menus").value;		
		if (window.XMLHttpRequest) {
			xmlhttp = new XMLHttpRequest();
		} else {
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		}	
		xmlhttp.onreadystatechange = 
		function(){
		if(xmlhttp.readyState == 4 && xmlhttp.status == 200){
			document.getElementById(menus).innerHTML = xmlhttp.responseText;
		}
		}	
		<?php 	
		if($this->session->userdata('search')){
		for($i = 1;$i <= $search_num;$i++){ ?>	
		xmlhttp.open("GET", "<?php echo base_url(); ?>"+menus+"/search?limit="+limit+"&page=<?php echo $this->session->userdata('page'); ?>&no=<?php echo $i; ?>&search=<?php echo $this->session->userdata('search'.$page.$i); ?>&ID2=<?php if($this->input->get('ID2')){echo $this->input->get('ID2');} ?>",true);
		<?php } 
		}else{
		?>
		xmlhttp.open("GET", "<?php echo base_url(); ?>"+menus+"?limit="+limit+"&page=<?php echo $this->session->userdata('page'); ?>&ID2=<?php if($this->input->get('ID2')){echo $this->input->get('ID2');} ?>",true);
		<?php } ?>
		xmlhttp.send();
	}
	
	function sorting(a,b,c) {
	if (window.XMLHttpRequest) {
		xmlhttp = new XMLHttpRequest();
	} else {
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}	
	xmlhttp.onreadystatechange = 
		function(){
		if(xmlhttp.readyState == 4 && xmlhttp.status == 200){
			document.getElementById(menus).innerHTML = xmlhttp.responseText;
		}
		}	
		xmlhttp.open("GET", "<?php echo base_url(); ?>"+menus+"/sorting?a="+a+"&b="+b+"&c="+c+"&page=<?php echo $page; ?>",true);
		xmlhttp.send();
	}
	
	function sortingby(a,b,c) {		
		var strURL="<?php echo base_url(); ?>"+b+"/sorting?a="+a+"&b="+b+"&c="+c;
		var req = new XMLHttpRequest();
		
		if (req) {
			req.onreadystatechange = function() {
				if (req.readyState == 4) {
					// only if "OK"
					if (req.status == 200) {						
						//document.getElementById('idTipee').innerHTML=req.responseText;						
					} else {
						//alert("There was a problem while using XMLHTTP:\n" + req.statusText);
					}
				}				
			}			
			req.open("GET", strURL, true);
			req.send(null);
		}		
	}
</script>
</body>

</html>