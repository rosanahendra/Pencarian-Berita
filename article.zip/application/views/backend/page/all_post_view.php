<section class="content" style="margin-top:-70px;"> 
    <div class="box">
    	<section class="content-header">
    	  <?php 
    	    if($this->input->get('status')){
    	  ?>  
    	  <h1>
    		<font style="color:#000; font-size:24px;"> 
    			<i class="fa fa-tag"></i>
    			Data Article (Published)
    		</font>
    	  </h1>
    	  <?php } else { ?>
    	  <h1>
    		<font style="color:#000; font-size:24px;"> 
    			<i class="fa fa-tag"></i>
    			All Post
    		</font>
    	  </h1>
    	  <div style="color:#000000;">Silakan klik tab di bawah ini untuk menampilkan data</div>
    	  <?php } ?>
    	</section>
    	<div class="box-body">
    	    <?php 
    	    if($this->input->get('status')){
    	    ?>
    	    <div>
    	        <?php 
    			if($publish){
    			echo $publish;
    			} else {
    			?>
    			<div class="alert alert-success text-center">
    				<strong>Data is not available. </strong>
    			</div>
    			<?php
    			}
    			?>
    	    </div>
    	    <?php } else { ?>
    		<ul class="nav nav-tabs">
              <li class="active"><a data-toggle="tab" href="#Published" class="btn">Published</a></li>
              <li><a data-toggle="tab" href="#Drafts" class="btn">Drafts</a></li>
              <li><a data-toggle="tab" href="#Trashed" class="btn">Trashed</a></li>
            </ul>
            
            <div class="tab-content">
              <div id="Published" class="tab-pane fade in active">
                <p>
                    <?php 
        			if($publish){
        			echo $publish;
        			} else {
        			?>
        			<div class="alert alert-success text-center">
        				<strong>Data is not available. </strong>
        			</div>
        			<?php
        			}
        			?>
                </p>
              </div>
              <div id="Drafts" class="tab-pane fade">
                <p>
                    <?php 
        			if($draft){
        			echo $draft;
        			} else {
        			?>
        			<div class="alert alert-success text-center">
        				<strong>Data is not available. </strong>
        			</div>
        			<?php
        			}
        			?>
                </p>
              </div>
              <div id="Trashed" class="tab-pane fade">
                <p>
                    <?php 
        			if($trashed){
        			echo $trashed;
        			} else {
        			?>
        			<div class="alert alert-success text-center">
        				<strong>Data is not available. </strong>
        			</div>
        			<?php
        			}
        			?>
                </p>
              </div>
            </div>
            <?php } ?>
    	</div>
	</div>
</section>	