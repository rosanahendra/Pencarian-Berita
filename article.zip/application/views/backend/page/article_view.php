

<section class="content" style="margin-top:-70px;">      
	<div class="box">
    	<section class="content-header">
    	  <h1>
    		<font style="color:#000; font-size:24px;"> 
    			<i class="fa fa-tag"></i>
    			<?php echo $title; ?>
    		</font>
    	  </h1>
    	</section>
    	<div class="box-body">
    	    <form action="<?php echo site_url('article'); ?>" method="get">
    	    <select class="form-control" name="kategori">
    	        <option>Silakan Pilih Kategori Berita</option>
    	        <option value="Entertainment">Entertainment</option>
    	        <option value="Business">Business</option>
    	        <option value="Food">Food</option>
    	        <option value="Health">Health</option>
    	        <option value="Politics">Politics</option>
    	    </select>
    	    <div style="margin-top:20px;">
    	        <center>
    	        <input type="submit" class="btn btn-success" value="Cari Artikel">
    	        </center>
    	    </div>
    	    </form>
    	</div>
	    <div style="margin-top:60px;">
	        <?php
	        if($hasil){
	            echo '<div style="margin-bottom:20px; font-size:24px;"><center>Hasil Pencarian</center></div>';
	            echo $hasil;
	            /*$data = json_decode($hasil);	
                foreach($data as $row){
                    echo $row['status'];
                          
                }*/
	        }
	        ?>
	    </div>
	</div>
</section>		